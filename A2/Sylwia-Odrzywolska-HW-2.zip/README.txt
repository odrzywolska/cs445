CS445 Assignment 2

The purpose of this assignment was to extend existing classes. 
StringTokenizer was extended to include a method that puts the next tokens into an array. 
Random was extended to include a method that only returns values in a certain range. 

Note: Java and javac have to be defined in the path
      The junit4.jar must be in the default location (/usr/share/java/junit4.jar)

To compile project:
   $ make

To execute JUnit tests:
   $ make JUnitTest

To clean project:
   $ make clean
